# 1 String operations
sentence = "Learning Python is so fun!"
uppercase_sentence = sentence.upper()
length_of_sentence = len(sentence)
substring = sentence[:5]

print("Original Sentence:", sentence)
print("Uppercase Sentence:", uppercase_sentence)
print("Length of Sentence:", length_of_sentence)
print("Substring (first 5 characters):", substring)

# 2  operations and outputs
print("7 ** 2:", 7 ** 2)
print('"10" * 3:', "10" * 3)
print("64 // 9:", 64 // 9)
print("33 != 31:", 33 != 31)
print("92 <= 92:", 92 <= 92)
print("True and True:", True and True)
print("False or True:", False or True)

a = 45
a += 40
print("Updated a:", a)

b = 20
b *= 5
print("Updated b:", b)

# 3 Shopping list operations
shopping_list = ["apples", "bananas", "milk", "bread", "eggs"]
shopping_list.append("chocolate")
shopping_list.remove("milk")
third_item = shopping_list[2]

print("Third item in the list:", third_item)
print("Entire shopping list:", shopping_list)
print("Length of shopping list:", len(shopping_list))

