import random

def number_guessing_game():
    selected_number = random.randint(1, 100)
 
    while True:
        try:
            guess = int(input("Guess the number between 1 and 100: "))
            if guess > selected_number:
                print("Too high!")
            elif guess < selected_number:
                print("Too low!")
            else:
                print("Congratulations! You guessed it!")
                break
        except ValueError:
            print("Invalid input. Please enter a number between 1 and 100.")

number_guessing_game()
