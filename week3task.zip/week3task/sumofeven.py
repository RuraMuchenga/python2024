def sum_of_even_numbers():
    numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    sum_even = 0
    for number in numbers:
        if number % 2 == 0:
            sum_even += number
    print(f"The sum of all even numbers in the list is: {sum_even}")

sum_of_even_numbers()
